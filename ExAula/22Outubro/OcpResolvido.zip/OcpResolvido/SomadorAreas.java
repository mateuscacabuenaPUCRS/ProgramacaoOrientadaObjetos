import java.util.ArrayList;

public abstract class SomadorAreas {

    public abstract double calculaArea();
}