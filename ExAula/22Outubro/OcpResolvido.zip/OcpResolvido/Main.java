public class Main {

    public static void main(String args[]) {
        Aplicacao aplicacao = new Aplicacao();
        aplicacao.executa();
    }
}
